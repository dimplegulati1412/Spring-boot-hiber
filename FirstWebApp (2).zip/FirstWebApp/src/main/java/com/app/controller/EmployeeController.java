package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.app.model.*;
@Controller
public class EmployeeController {
 @Autowired
 EmployeeRepository emprep;
    @RequestMapping(value = "/employee", method = RequestMethod.GET)
    public ModelAndView showForm() {
        return new ModelAndView("EmployeeForm", "employee", new Employee());//Backing bean
    }
 
    @RequestMapping(value = "/addEmployee", method = RequestMethod.POST)
    public String submit(@ModelAttribute("employee")Employee employee, 
      BindingResult result, ModelMap model) {
        if (result.hasErrors()) {
            return "error";
        }
        emprep.save(employee);
        System.out.println("Data saved");
        model.addAttribute("named", employee.getName());
        model.addAttribute("contactNumberd", employee.getContactnumber());
        model.addAttribute("idd", employee.getId());
        return "EmployeeData";
    }
}